<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/detail-type-style.css')); ?>">
</head>
<body>
    <header>
        <div class="title" style="background: url(<?php echo e($cover_path); ?>);">
            <h1><?php echo e($title); ?></h1>
            <p style="text-align: center;"><?php echo e($subtitle); ?></p>
        </div>
        <nav>
            <ul>
                <li><a href="/">Beranda</a></li>
                <li><a href="/type" style="font-weight: bold;">Jenis</a></li>
                <li><a href="/gallery">Galeri</a></li>
                <li><a href="/contact">Kontak</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div id="content">
            <h2>Penelusuran Tari</h2>
            <input type="text" name="search_bar" id="search_bar" placeholder="Telusuri Tari. . .">
            <br><br>

            <?php $__empty_1 = true; $__currentLoopData = $dances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article id="jenis">
                    <a href="/dance/<?php echo e($dance->slug); ?>">
                        <section class="card">
                            <img src="<?php echo e($dance->image_path); ?>" alt="<?php echo e($dance->name); ?>">
                            <h3><?php echo e($dance->name); ?></h3>
                            
                            <p><?php echo $dance->description; ?></p>
                        </section>
                    </a>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <section class="empty">
                    <img src="<?php echo e(asset('images/balinese.png')); ?>" alt="">
                    <p>Maaf data tari tidak ditemukan!</p>
                </section>
            <?php endif; ?>

        </div>
    </main>

    <footer>
        <p>Warisan Budaya Digital</p>
    </footer>
</body>
</html><?php /**PATH D:\Project\project-warbudi\resources\views/detail-type.blade.php ENDPATH**/ ?>